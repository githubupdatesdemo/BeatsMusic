package com.mbit.VideoMaker.View;

import android.content.Context;

public class IndicatorContext {
    public static int a(Context context, float f) {
        return (int) ((f * context.getResources().getDisplayMetrics().density) + 0.5f);
    }

}
