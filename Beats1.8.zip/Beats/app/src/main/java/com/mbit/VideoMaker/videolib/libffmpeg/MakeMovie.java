package com.mbit.VideoMaker.videolib.libffmpeg;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeoutException;

public class MakeMovie extends Service
{
  private long timeout;

  public MakeMovie() {
    this.timeout = Long.MAX_VALUE;
  }

  public IBinder onBind(final Intent arg0) {
    return null;
  }

  class TaskCreateSingleImageVideo extends AsyncTask<Void, String, Void>
  {
    String[] cmdArr;
    private String output;
    private Process process;
    private ShellCommand shellCommand;
    private long startTime;

    public TaskCreateSingleImageVideo(final int imgNo) {
      this.shellCommand = new ShellCommand();
      this.cmdArr = new String[0];
    }

    protected void onPreExecute() {
      this.startTime = System.currentTimeMillis();
    }

    protected Void doInBackground(final Void... params) {
      this.process = this.shellCommand.run(this.cmdArr);
      if (this.process != null) {
        try {
          this.checkAndUpdateProcess();
        }
        catch (TimeoutException e) {
          e.printStackTrace();
        }
        catch (InterruptedException e2) {
          e2.printStackTrace();
        }
      }
      return null;
    }

    private void checkAndUpdateProcess() throws TimeoutException, InterruptedException {
      while (!Util.isProcessCompleted(this.process)) {
        if (Util.isProcessCompleted(this.process)) {
          return;
        }
        if (MakeMovie.this.timeout != Long.MAX_VALUE && System.currentTimeMillis() > this.startTime + MakeMovie.this.timeout) {
          throw new TimeoutException("FFmpeg timed out");
        }
        try {
          final BufferedReader reader = new BufferedReader(new InputStreamReader(this.process.getErrorStream()));
          String line;
          while ((line = reader.readLine()) != null) {
            if (this.isCancelled()) {
              return;
            }
            this.output = String.valueOf(String.valueOf(this.output)) + line + "\n";
            this.publishProgress(new String[] { line });
          }
        }
        catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
  }
}
