package com.mbit.VideoMaker.View;

import android.view.View;

public class ExpandableClick implements View.OnClickListener {
    public final  ExpandableView expandableView;

    public ExpandableClick(ExpandableView expandableView) {
        this.expandableView = expandableView;
    }

    public void onClick(View view) {
        ExpandableView expandableView = this.expandableView;
        expandableView.ZoomImage(expandableView.n);
    }

}
