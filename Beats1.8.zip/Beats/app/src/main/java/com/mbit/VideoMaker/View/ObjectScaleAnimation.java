package com.mbit.VideoMaker.View;

import android.animation.Animator;
import android.view.View;
import com.mbit.VideoMaker.Adapter.AlbumWiseFolder;

public class ObjectScaleAnimation implements Animator.AnimatorListener {
    public final CircleImageView circleImageView;
    public final AlbumWiseFolder albumWiseFolder;

    public ObjectScaleAnimation(AlbumWiseFolder hVar, CircleImageView circleImageview) {
        this.albumWiseFolder = hVar;
        this.circleImageView = circleImageview;
    }

    public void onAnimationCancel(Animator animator) {
    }

    public void onAnimationEnd(Animator animator) {
        this.circleImageView.setVisibility(View.INVISIBLE);
    }

    public void onAnimationRepeat(Animator animator) {
    }

    public void onAnimationStart(Animator animator) {
        this.circleImageView.setVisibility(View.VISIBLE);
    }
}
