package com.mbit.VideoMaker.videolib.libffmpeg;

import android.content.Context;

import com.mbit.VideoMaker.Extra.Utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.Map;

public class FileUtils {
    public static long mDeleteFileCount;


    static {
        FileUtils.mDeleteFileCount = 0L;

    }

    public FileUtils() {
        FileUtils.mDeleteFileCount = 0L;
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        FileUtils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                FileUtils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                FileUtils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        return idDelete;
    }

    public static boolean deleteFile(final String s) {
        return deleteFile(new File(s));
    }


    static boolean copyBinaryFromSDCardToData(final Context context, final String fileNameFromAssets, final String outputFileName) {
        final File filesDirectory = getFilesDirectory(context);
        try {
            final InputStream is = new FileInputStream(getFileDownloadName(fileNameFromAssets));
            final OutputStream os = new FileOutputStream(new File(filesDirectory, outputFileName));
            final byte[] buffer = new byte[4096];
            while (true) {
                final int n = is.read(buffer);
                if (-1 == n) {
                    break;
                }
                os.write(buffer, 0, n);
            }
            Util.close(os);
            Util.close(is);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static String getFileDownloadName(final String mArcName) {
        final String path = String.valueOf(getHiddenFolderPath()) + File.separator + mArcName;
        return path;
    }

    public static String getHiddenFolderPath() {
        final String path = String.valueOf(Utils.INSTANCE.getOutputPath()) + ".ffmpeg";
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    static File getFilesDirectory(final Context context) {
        return context.getFilesDir();
    }

    public static String getFFmpeg(final Context context) {
        return String.valueOf(String.valueOf(getFilesDirectory(context).getAbsolutePath())) + File.separator + "ffmpeg";
    }

    static String getFFmpeg(final Context context, final Map<String, String> environmentVars) {
        String ffmpegCommand = "";
        if (environmentVars != null) {
            for (final Map.Entry<String, String> var : environmentVars.entrySet()) {
                ffmpegCommand = String.valueOf(String.valueOf(ffmpegCommand)) + var.getKey() + "=" + var.getValue() + " ";
            }
        }
        ffmpegCommand = String.valueOf(String.valueOf(ffmpegCommand)) + getFFmpeg(context);
        return ffmpegCommand;
    }

    static String SHA1(final String file) {
        InputStream is = null;
        try {
            is = new BufferedInputStream(new FileInputStream(file));
            return SHA1(is);
        } catch (IOException e) {
            Log.e(e);
        } finally {
            Util.close(is);
        }
        return null;
    }

    static String SHA1(final InputStream is) {
        try {
            final MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
            final byte[] buffer = new byte[4096];
            int read;
            while ((read = is.read(buffer)) != -1) {
                messageDigest.update(buffer, 0, read);
            }
            final Formatter formatter = new Formatter();
            byte[] digest;
            for (int length = (digest = messageDigest.digest()).length, i = 0; i < length; ++i) {
                final byte b = digest[i];
                formatter.format("%02x", b);
            }
            return formatter.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(e);
        } catch (IOException e2) {
            Log.e(e2);
        } finally {
            Util.close(is);
        }
        return null;
    }


}
