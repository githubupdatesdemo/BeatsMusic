package com.mbit.VideoMaker.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.mbit.VideoMaker.Fragment.LocalSongFragment;
import com.mbit.VideoMaker.Fragment.OnlineCategoryWiseSongFragment;
import com.mbit.VideoMaker.Fragment.OnlineSongFragment;
import com.mbit.VideoMaker.R;
import com.unity3d.player.UnityPlayer;
import java.util.ArrayList;
import java.util.List;
import static com.mbit.VideoMaker.Fragment.LocalCategoryWiseSongFragment.localSongFragment;

public class SongSelectActivity extends AppCompatActivity {

    public InterstitialAd mInterstitialAd;
    public int id;
    public String FinalSongPath;
    Activity activity = SongSelectActivity.this;
    ImageView ivback;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private String SongAllCategory = "https://raw.githubusercontent.com/githubupdatesdemo/BeatsMusic/master/MainCategory.txt";
    private LinearLayout adContainer;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_select);
        BindView();
        loadAd();
        InterstitialAd();
        CreateViewPager(viewPager);
        SetTabLayout();
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        tabLayout = findViewById(R.id.tab_layout_song);
        viewPager = findViewById(R.id.pager);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void loadAd() {
        adContainer = findViewById(R.id.templateContainer);
        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
        adContainer.addView(adView);
        adView.loadAd();
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 102:
                        if (localSongFragment != null) {
                            localSongFragment.Done();
                            finish();
                        }
                        break;
                    case 103:
                        UnityPlayer.UnitySendMessage("SelectMusic", "GetSelectedMusicPath", FinalSongPath);
                        finish();
                        break;
                }
            }

        });
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    private void CreateViewPager(ViewPager viewPager) {
        ThemeHomePagerAdapter themePageradapter = new ThemeHomePagerAdapter(getSupportFragmentManager());
        themePageradapter.addFragment(OnlineSongFragment.getInstance(SongAllCategory), "");
        themePageradapter.addFragment(LocalSongFragment.getInstance(), "");
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setAdapter(themePageradapter);
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        View inflate = getLayoutInflater().inflate(R.layout.custom_catmain_tab, null);
        ((TextView) inflate.findViewById(R.id.ThemeTab)).setText("Popular");
        View inflate2 = getLayoutInflater().inflate(R.layout.custom_catmain_tab, null);
        TextView textView = inflate2.findViewById(R.id.ThemeTab);
        inflate2.findViewById(R.id.underLine);
        textView.setText("Library");

        tabLayout.getTabAt(0).setCustomView(inflate);
        tabLayout.getTabAt(1).setCustomView(inflate2);

        if (tabLayout.getTabAt(0).getPosition() == 0) {
            View customView = tabLayout.getTabAt(0).getCustomView();
            ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.white));
            customView.findViewById(R.id.underLine).setVisibility(View.VISIBLE);
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.white));
                customView.findViewById(R.id.underLine).setVisibility(View.VISIBLE);
                if (tab.getPosition() == 0) {
                    StopSong(OnlineCategoryWiseSongFragment.mediaPlayer);
                }
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                TextView textView = customView.findViewById(R.id.ThemeTab);
                textView.setTextColor(getResources().getColor(R.color.white));
                ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.light_gray_tab));
                customView.findViewById(R.id.underLine).setVisibility(View.GONE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.white));
                customView.findViewById(R.id.underLine).setVisibility(View.GONE);
            }
        });
    }

    private void StopSong(MediaPlayer mediaPlayer) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private class ThemeHomePagerAdapter extends FragmentPagerAdapter {

        List<Fragment> mFragments = new ArrayList<>();
        List<String> mFragmentsTitle = new ArrayList<>();

        public ThemeHomePagerAdapter(FragmentManager fm) {
            super(fm);
        }

        public void addFragment(Fragment f, String s) {
            mFragments.add(f);
            mFragmentsTitle.add(s);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentsTitle.get(position);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragments.get(position);
        }

        @Override
        public int getCount() {
            return mFragments.size();
        }
    }
}


