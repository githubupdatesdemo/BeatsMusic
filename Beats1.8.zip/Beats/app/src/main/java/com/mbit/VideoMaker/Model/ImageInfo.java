package com.mbit.VideoMaker.Model;

import android.text.TextUtils;

public class ImageInfo {
  public String ImagePath;
  public String ImageAlbum;
  public String ThumbbailImage;
  public String folderName;
  public int NoOfImage = 0;
  public long id;
  public boolean isSupported = true;

  public ImageInfo() {}
  
  public String getThumbbailImage() {
    return ThumbbailImage;
  }
  
  public void setThumbbailImage(String thumbbailImage) {
    this.ThumbbailImage = thumbbailImage;
  }
  
  public String getImagePath() {
    return ImagePath;
  }
  
  public void setImagePath(String imagePath) {
    this.ImagePath = imagePath;
  }
  
  public String getImageAlbum() {
    return ImageAlbum;
  }
  
  public void setImageAlbum(String imageAlbum) {
    this.ImageAlbum = imageAlbum;
  }
  
  public int getNoOfImage() {
    return NoOfImage;
  }
  
  public void setNoOfImage(int noOfImage) {
    this.NoOfImage = noOfImage;
  }
  
  public long getId() {
    return id;
  }
  
  public void setId(long id) {
    this.id = id;
  }
  
  public String toString()
  {
    if (!TextUtils.isEmpty(ImagePath)) {
      return
        "ImageData { PathOfImage=" + ImagePath + ",folderName=" + folderName + ",NoOfImage=" + NoOfImage + " }";

    }
    return super.toString();
  }


}
