package com.mbit.VideoMaker.cropImage;

import android.graphics.Bitmap;

public class ad {
    public static Bitmap a(Bitmap bitmap, int i, int i2) {
        return b.a(b.a(c.as(bitmap, i, i2), 25, true), 25, true);
    }

}
