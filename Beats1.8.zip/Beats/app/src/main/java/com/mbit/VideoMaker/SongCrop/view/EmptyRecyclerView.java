package com.mbit.VideoMaker.SongCrop.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;

public class EmptyRecyclerView extends RecyclerView {
    private View view;
    private AdapterDataObserver adapterDataObserver;

    class C26471 extends AdapterDataObserver {
        final  EmptyRecyclerView emptyRecyclerView;

        C26471(EmptyRecyclerView emptyRecyclerView) {
            this.emptyRecyclerView = emptyRecyclerView;
        }

        public void onChanged() {
            Adapter adapter = this.emptyRecyclerView.getAdapter();
            if (!(adapter == null || this.emptyRecyclerView.view == null)) {
                if (adapter.getItemCount() == 0) {
                    this.emptyRecyclerView.view.setVisibility(VISIBLE);
                    this.emptyRecyclerView.setVisibility(GONE);
                    return;
                }
                this.emptyRecyclerView.view.setVisibility(GONE);
                this.emptyRecyclerView.setVisibility(VISIBLE);
            }
        }
    }

    public EmptyRecyclerView(Context context) {
        this(context, null);
    }

    public EmptyRecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public EmptyRecyclerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.adapterDataObserver = new C26471(this);
    }

    public void setAdapter(Adapter adapter) {
        super.setAdapter(adapter);
        if (adapter != null) {
            adapter.registerAdapterDataObserver(this.adapterDataObserver);
        }
        this.adapterDataObserver.onChanged();
    }

    public void setEmptyView(View view) {
        this.view = view;
    }
}
