package com.mbit.VideoMaker.application;


import android.content.Context;
import android.graphics.Typeface;
import android.widget.TextView;

public class AppFontStyle {

    public static void Textfont(final Context mContext, final TextView tv) {
        final Typeface typeFacecategory = Typeface.createFromAsset(mContext.getAssets(), "fonts/OpenSans_Regular.ttf");
        tv.setTypeface(typeFacecategory);
    }

}
