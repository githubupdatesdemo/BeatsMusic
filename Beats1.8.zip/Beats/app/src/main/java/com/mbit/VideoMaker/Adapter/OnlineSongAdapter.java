package com.mbit.VideoMaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mbit.VideoMaker.Activity.SongSelectActivity;
import com.mbit.VideoMaker.Download.SongDownload;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Fragment.OnlineCategoryWiseSongFragment;
import com.mbit.VideoMaker.Model.OnlineSongModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.View.CircleImageView;
import com.mbit.VideoMaker.View.DonutProgress;
import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.util.List;

public class OnlineSongAdapter extends RecyclerView.Adapter<OnlineSongAdapter.SongViewHolder> {


    public static boolean IsSongPlay = false;
    OnlineCategoryWiseSongFragment songFragment;
    private int selectedPosition = -1;
    private List<OnlineSongModel> songList;
    private Context mContext;
    private SongSelectActivity ActivityOfsong;


    public OnlineSongAdapter(Context mContext, List<OnlineSongModel> songList, OnlineCategoryWiseSongFragment songFragment) {
        this.songList = songList;
        this.mContext = mContext;
        this.ActivityOfsong = (SongSelectActivity) mContext;
        this.songFragment = songFragment;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_online_song_item, null);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SongViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final OnlineSongModel songModel = songList.get(position);
        holder.tvSongName.setText(songList.get(position).getSongName());
        holder.cbSong.setChecked(selectedPosition == position);
        if (!songList.get(position).isAvailableOffline) {
            if (songList.get(position).isDownloading) {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.GONE);
                holder.dpDownSong.setVisibility(View.VISIBLE);
            } else {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.VISIBLE);
                holder.dpDownSong.setVisibility(View.GONE);
            }
        } else {
            holder.layoutUseSong.setVisibility(View.VISIBLE);
            holder.ivDownload.setVisibility(View.GONE);
            holder.dpDownSong.setVisibility(View.GONE);
        }
        if (selectedPosition == position) {
            holder.cbSong.setChecked(true);
            holder.cvThumb.setBackgroundResource(R.drawable.img_ring_press);
            holder.ivPalayPause.setImageResource(R.drawable.icon_player_pause);

        } else {
            holder.cbSong.setChecked(false);
            holder.cvThumb.setBackgroundResource(R.drawable.img_ring);
            holder.ivPalayPause.setImageResource(R.drawable.icon_player_play);
        }

        holder.tvUseSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityOfsong.FinalSongPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songList.get(position).getSongUrl();
                if (ActivityOfsong.mInterstitialAd != null && ActivityOfsong.mInterstitialAd.isLoaded()) {
                    songFragment.stopPlaying(songFragment.mediaPlayer);
                    ActivityOfsong.id = 103;
                    ActivityOfsong.mInterstitialAd.show();
                } else {
                    songFragment.stopPlaying(songFragment.mediaPlayer);
                    UnityPlayer.UnitySendMessage("SelectMusic", "GetSelectedMusicPath", ActivityOfsong.FinalSongPath);
                    ((Activity) mContext).finish();
                }

            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadSongFiles(position, holder.ivDownload, holder.dpDownSong, holder.layoutUseSong, holder.ivPalayPause, songModel);
            }
        });
    }


    private void DownloadSongFiles(int position, ImageView ivDonload, DonutProgress dpSongProgress, LinearLayout layoutUseSong, ImageView ivplapause, OnlineSongModel themelModel) {
        int UnitySoundSize = Integer.parseInt(songList.get(position).getSongSize());
        String SongName = songList.get(position).getSongUrl();
        File SongPath = new File(Utils.INSTANCE.getMusicFolderPath() + File.separator + SongName);
        int SoundFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        if (new File(Utils.INSTANCE.getMusicFolderPath() + SongName).exists()) {
            if (SoundFileSize == UnitySoundSize) {
                songFragment.rePlayAudio(position, true);
                selectedPosition =position;
                notifyDataSetChanged();
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDonload.setVisibility(View.GONE);
                    dpSongProgress.setVisibility(View.VISIBLE);
                    new SongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDonload.setVisibility(View.GONE);
                dpSongProgress.setVisibility(View.VISIBLE);
                new SongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, themelModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }


    public class SongViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutMain;
        CircleImageView cvThumb;
        ImageView ivPalayPause;
        TextView tvSongName, tvSongTime;
        LinearLayout layoutUseSong;
        TextView tvUseSong;
        LinearLayout layoutDownSong;
        ImageView ivDownload;
        DonutProgress dpDownSong;
        CheckBox cbSong;

        public SongViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutMain = itemView.findViewById(R.id.image_layout);
            cvThumb = itemView.findViewById(R.id.image_content);
            ivPalayPause = itemView.findViewById(R.id.ivPopularPlayPause);
            tvSongName = itemView.findViewById(R.id.tvMusicName);
            tvSongTime = itemView.findViewById(R.id.tvMusicEndTime);
            layoutUseSong = itemView.findViewById(R.id.llUseMusic);
            tvUseSong = itemView.findViewById(R.id.tvUseMusic);
            layoutDownSong = itemView.findViewById(R.id.ll_download);
            ivDownload = itemView.findViewById(R.id.iv_dowload);
            dpDownSong = itemView.findViewById(R.id.donut_progress);
            cbSong = itemView.findViewById(R.id.cb_music);

        }


    }
}
