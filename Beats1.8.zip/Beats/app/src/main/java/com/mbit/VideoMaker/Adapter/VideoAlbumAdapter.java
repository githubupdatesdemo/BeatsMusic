package com.mbit.VideoMaker.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mbit.VideoMaker.Activity.VideoPlayerActivity;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Model.VideoData;
import com.mbit.VideoMaker.R;

import java.io.File;
import java.util.ArrayList;

public class VideoAlbumAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private ArrayList<VideoData> mVideoDatas;

    public VideoAlbumAdapter(Context mContext, ArrayList<VideoData> mVideoDatas) {
        this.mContext = mContext;
        this.mVideoDatas = mVideoDatas;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.row_myvideo, parent, false);
        return new MyViewHolder(v);
    }

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final MyViewHolder myViewHolder = (MyViewHolder) holder;
        final StaggeredGridLayoutManager.LayoutParams layoutParams = new StaggeredGridLayoutManager.LayoutParams(myViewHolder.itemView.getLayoutParams());
        layoutParams.setFullSpan(false);
        myViewHolder.itemView.setLayoutParams(layoutParams);

        Glide.with(this.mContext).load(mVideoDatas.get(position).videoFullPath).into(myViewHolder.ivVideoThumb);

        myViewHolder.ivPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                Intent i = new Intent(mContext, VideoPlayerActivity.class);
                i.putExtra("VideoUrl",mVideoDatas.get(position).videoFullPath);
                i.putExtra("VideoName", mVideoDatas.get(position).videoName + ".mp4");
                i.putExtra("VideoPosition", position);
                i.putExtra("IsVideoFromAndroidList", true);
                i.putExtra("AllVideoList", mVideoDatas);
                mContext.startActivity(i);
            }
        });
        myViewHolder.ivDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                try {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(VideoAlbumAdapter.this.mContext, R.style.AppDialog);
                    builder.setTitle(R.string.deletetitle);
                    builder.setMessage(String.valueOf(VideoAlbumAdapter.this.mContext.getResources().getString(R.string.deleteMessage)) + VideoAlbumAdapter.this.mVideoDatas.get(position).videoName + ".mp4" + " ?");
                    builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialog, final int which) {
                            try {
                                Utils.deleteFile(new File(VideoAlbumAdapter.this.mVideoDatas.get(position).videoFullPath));
                                itemRemoved(position);
                                VideoAlbumAdapter.this.notifyDataSetChanged();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    builder.setNegativeButton("Cancel", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(mContext.getResources().getColor(R.color.barColor));
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(mContext.getResources().getColor(R.color.barColor));
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(mContext.getResources().getColor(R.color.barColor));
                } catch (Resources.NotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
        myViewHolder.ivShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                final File file = new File(VideoAlbumAdapter.this.mVideoDatas.get(position).videoFullPath);
                final Intent shareIntent = new Intent("android.intent.action.SEND");
                shareIntent.setType("video/*");
                shareIntent.putExtra("android.intent.extra.SUBJECT", VideoAlbumAdapter.this.mContext.getString(R.string.app_name));
                shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(VideoAlbumAdapter.this.mContext.getString(R.string.get_free_)) + VideoAlbumAdapter.this.mContext.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + VideoAlbumAdapter.this.mContext.getPackageName());
                shareIntent.putExtra("android.intent.extra.TITLE", VideoAlbumAdapter.this.mVideoDatas.get(position).videoName);
                final Uri ShareUri = FileProvider.getUriForFile(VideoAlbumAdapter.this.mContext, String.valueOf(VideoAlbumAdapter.this.mContext.getPackageName()) + ".provider", file);
                shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                VideoAlbumAdapter.this.mContext.startActivity(Intent.createChooser(shareIntent, "Share Video"));
            }
        });
    }


    public void itemRemoved(int pos) {
        if ((mVideoDatas != null) && (mVideoDatas.size() > 0)) {
            mVideoDatas.remove(pos);
        }
    }

    public int getItemCount() {
        return mVideoDatas.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView ivVideoThumb;
        ImageView ivPlay;
        TextView tvVideoName;
        ImageView ivShare;
        ImageView ivDelete;

        public MyViewHolder(View v) {
            super(v);
            ivVideoThumb = v.findViewById(R.id.iv_videoplayer_thumb);
            tvVideoName=v.findViewById(R.id.tv_videoName);
            ivShare = v.findViewById(R.id.ivShare);
            ivDelete = v.findViewById(R.id.ivDelete);
            ivPlay = v.findViewById(R.id.ivPlay_vc);
        }
    }

}
