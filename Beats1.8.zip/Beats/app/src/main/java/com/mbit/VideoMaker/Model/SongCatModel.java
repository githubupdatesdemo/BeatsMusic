package com.mbit.VideoMaker.Model;

public class SongCatModel {
    private String SongCatId;
    private String SongCatName;
    private String SongCatLnk;
    private String ApplicationId;

    public String getSongCatId() {
        return SongCatId;
    }

    public void setSongCatId(String songCatId) {
        SongCatId = songCatId;
    }

    public String getSongCatName() {
        return SongCatName;
    }

    public void setSongCatName(String songCatName) {
        SongCatName = songCatName;
    }

    public String getSongCatLnk() {
        return SongCatLnk;
    }

    public void setSongCatLnk(String songCatLnk) {
        SongCatLnk = songCatLnk;
    }

    public String getApplicationId() {
        return ApplicationId;
    }

    public void setApplicationId(String applicationId) {
        ApplicationId = applicationId;
    }
}
