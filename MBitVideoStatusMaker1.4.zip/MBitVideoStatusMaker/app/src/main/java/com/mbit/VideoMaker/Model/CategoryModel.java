package com.mbit.VideoMaker.Model;

public class CategoryModel {
    private String ThemeId, name, appid;
    private int CatIcon;

    public int getCatIcon() {
        return CatIcon;
    }

    public void setCatIcon(int catIcon) {
        CatIcon = catIcon;
    }

    public String getThemeId() {
        return ThemeId;
    }

    public void setThemeId(String themeId) {
        this.ThemeId = themeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

}
