//package com.mbit.VideoMaker.cropImage;
//
//import android.annotation.SuppressLint;
//import android.app.Activity;
//import android.app.Dialog;
//import android.content.ContentResolver;
//import android.content.Context;
//import android.content.Intent;
//import android.graphics.Bitmap;
//import android.graphics.Color;
//import android.graphics.drawable.ColorDrawable;
//import android.net.Uri;
//import android.os.AsyncTask;
//import android.util.DisplayMetrics;
//import android.view.Window;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.example.pkfilms.R;
//import com.example.pkfilms.activity.ArrangePhotosActivity;
//import com.example.pkfilms.activity.ImageSelectActivity;
//import com.example.pkfilms.application.MyApplication;
//import com.mbit.VideoMaker.application.MyApplication;
//
//import java.io.Closeable;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStream;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//
//public class Utils {
//    public static final String CropTempImg = "CropTempImg";
//    public static final String TAG = "autocrop";
//    private static final String APP_FOLDER = "Rk Films";
//    private static ContentResolver mContentResolver_AC;
//    private final Bitmap.CompressFormat mOutputFormat_AC;
//    String[] mAllPath_AC;
//    ArrayList<String> mAllSavePath_AC;
//    String mConcatPath_AC;
//    String save_path_AC;
//    Context mContext_AC;
//    private String mImagePath_AC;
//    private Uri mImageUri_AC;
//    private Uri mSaveUri_AC;
//    private MyApplication application;
//    ;
//
//    public Utils() {
//        this.mOutputFormat_AC = Bitmap.CompressFormat.JPEG;
//        application = MyApplication.getInstance();
//    }
//
//    public static Uri getImageUri(final String path) {
//        return Uri.fromFile(new File(path));
//    }
//
//    public static void copy(final File src, final File dst) throws IOException {
//        final InputStream in = new FileInputStream(src);
//        try {
//            final OutputStream out = new FileOutputStream(dst);
//            final byte[] buf = new byte[1024];
//            while (true) {
//                final int len = in.read(buf);
//                if (len <= 0) {
//                    break;
//                }
//                out.write(buf, 0, len);
//            }
//            out.close();
//            in.close();
//        } catch (Throwable th) {
//            in.close();
//        }
//    }
//
//    static void close(final OutputStream outputStream) {
//        if (outputStream != null) {
//            try {
//                outputStream.flush();
//                outputStream.close();
//            } catch (IOException ex) {
//            }
//        }
//    }
//
//    static void close(final InputStream inputStream) {
//        if (inputStream != null) {
//            try {
//                inputStream.close();
//            } catch (IOException ex) {
//            }
//        }
//    }
//
//    public void startAutoCrop(final Context con, final String all_path) {
//        this.mContext_AC = con;
//        Utils.mContentResolver_AC = this.mContext_AC.getContentResolver();
//        this.mConcatPath_AC = "";
//        this.mSaveUri_AC = null;
//        this.mImageUri_AC = null;
//        this.save_path_AC = null;
//        this.mAllSavePath_AC = new ArrayList<String>();
//        this.setImageBunch(all_path);
//    }
//
//    public void setImageBunch(final String allToCrop) {
//        if (allToCrop.equals("")) {
//            return;
//        }
//        this.mAllPath_AC = allToCrop.split("\\" + MyApplication.APP_SPLIT_PATTERN);
//        this.mConcatPath_AC = allToCrop;
//        new SaveSingleAsynk().execute();
//
//    }
//
//    private Bitmap a(String s, final int n, final int n2) {
//        final StringBuilder sb = new StringBuilder("Path = ");
//        sb.append(s);
//        final StringBuilder sb2 = new StringBuilder("WIDTH = ");
//        sb2.append(n);
//        final StringBuilder sb3 = new StringBuilder("HEIGHT = ");
//        sb3.append(n2);
//        final Bitmap a = C1721b.m5448a(s);
//        final Bitmap a2 = C1721b.m5446a(a, n, n2);
//        final Bitmap a3 = C1721b.m5447a(a, a2, n, n2);
//        a2.recycle();
//        a.recycle();
//        System.gc();
//        if (a3 == null) {
//            s = "newFirstBmp==null";
//        } else {
//            s = "newFirstBmp!=null";
//        }
//        return a3;
//    }
//
//    public boolean saveCropResult(final int idx) {
//        if (this.save_path_AC == null) {
//            this.save_path_AC = com.example.pkfilms.Utils.Utils.INSTANCE.getCropImagePath();
//        }
//        this.mImagePath_AC = this.mAllPath_AC[idx];
//        this.mImageUri_AC = getImageUri(this.mImagePath_AC);
//        final String file_path = this.getOutFilePath(this.mAllPath_AC[idx], idx);
//        try {
//            final DisplayMetrics displayMetrics = new DisplayMetrics();
//            ((ImageSelectActivity) this.mContext_AC).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//            final int height = displayMetrics.heightPixels;
//            final int width = displayMetrics.widthPixels;
//            final Bitmap croppedImage = BitmapUtil.centerCrop(a(this.mImagePath_AC, width, height), width, height);
//            this.mSaveUri_AC = getImageUri(file_path);
//            if (this.mSaveUri_AC != null) {
//                OutputStream outputStream = null;
//                try {
//                    outputStream = Utils.mContentResolver_AC.openOutputStream(this.mSaveUri_AC);
//                    if (outputStream != null) {
//                        croppedImage.compress(this.mOutputFormat_AC, 100, outputStream);
//                    }
//
//                    this.mAllSavePath_AC.add(file_path);
//                    croppedImage.recycle();
//                    return true;
//                } catch (IOException ex) {
//                    ex.printStackTrace();
//                    return false;
//                } finally {
//                    this.closeSilently(outputStream);
//                }
//            }
//            return false;
//        } catch (IllegalArgumentException e) {
//            return false;
//        } catch (Exception e2) {
//            return false;
//        }
//    }
//
//    public void closeSilently(final Closeable c) {
//        if (c != null) {
//            try {
//                c.close();
//            } catch (Throwable t) {
//            }
//        }
//    }
//
//    public String getOutFilePath(final String inPath, final int count) {
//        final String ext = new File(inPath).getName();
//        return String.valueOf(this.save_path_AC) + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + "_" + count + "_" + ext.substring(ext.lastIndexOf("."));
//    }
//
//    public void deleteRecursive(final File fileOrDirectory) {
//        if (fileOrDirectory.isDirectory()) {
//            File[] listFiles;
//            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
//                final File child = listFiles[i];
//                this.deleteRecursive(child);
//            }
//        }
//        fileOrDirectory.delete();
//    }
//
//
//    class SaveSingleAsynk extends AsyncTask<Integer, Integer, String> {
//        boolean isCropSuccess;
//        Dialog alertDialog;
//        TextView tvcount;
//
//
//        SaveSingleAsynk() {
//            this.isCropSuccess = false;
//        }
//
//        @Override
//        protected void onPreExecute() {
//            alertDialog = new Dialog(mContext_AC);
//            alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//            alertDialog.setCancelable(false);
//            alertDialog.setContentView(R.layout.image_auto_crop);
//            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//            tvcount = alertDialog.findViewById(R.id.tv_no_of_image_crop);
//            tvcount.setText("Loading Image..." + 0 + "/" + mAllPath_AC.length);
//            alertDialog.show();
//        }
//
//
//        @Override
//        protected String doInBackground(Integer... params) {
//            for (int i = 0; i < Utils.this.mAllPath_AC.length; ++i) {
//                this.isCropSuccess = Utils.this.saveCropResult(i);
//                publishProgress(i + 1);
//            }
//            return "Task Completed.";
//        }
//
//        @SuppressLint("SetTextI18n")
//        @Override
//        protected void onProgressUpdate(Integer... values) {
//            tvcount.setText("Loading Image..." + values[0] + "/" + mAllPath_AC.length);
//        }
//
//        @Override
//        protected void onPostExecute(String result) {
//
//            String Image_Path_Connect = "";
//            for (int i = 0; i < Utils.this.mAllSavePath_AC.size(); ++i) {
//                CropImage cropModel = new CropImage();
//                if (i == 0) {
//                    Image_Path_Connect = Utils.this.mAllSavePath_AC.get(i);
//                    cropModel.a(mAllSavePath_AC.get(i));
//
//                } else {
//                    Image_Path_Connect = String.valueOf(Image_Path_Connect) + MyApplication.APP_SPLIT_PATTERN + Utils.this.mAllSavePath_AC.get(i);
//                    cropModel.a(mAllSavePath_AC.get(i));
//                }
//                application.AddCropImages(cropModel);
//            }
//            if (this.alertDialog != null && this.alertDialog.isShowing()) {
//                this.alertDialog.dismiss();
//            }
//
//            Intent intent = new Intent(mContext_AC, ArrangePhotosActivity.class);
//            mContext_AC.startActivity(intent);
//            ((Activity) Utils.this.mContext_AC).finish();
//        }
//    }
//
//}
