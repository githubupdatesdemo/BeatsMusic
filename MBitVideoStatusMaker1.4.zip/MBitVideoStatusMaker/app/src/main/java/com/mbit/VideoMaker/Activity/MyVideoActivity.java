package com.mbit.VideoMaker.Activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.mbit.VideoMaker.Adapter.VideoAlbumAdapter;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Model.VideoData;
import com.mbit.VideoMaker.R;

import java.io.File;
import java.util.ArrayList;

public class MyVideoActivity extends AppCompatActivity {

    public ArrayList<VideoData> mVideoDatas;
    Activity activity = MyVideoActivity.this;
    LinearLayout llcreatevideo;
    ImageView ivBack;
    TextView txtMainTitle;
    String from = "";
    Button btncreatevideo;
    RecyclerView rvVideoList;
    VideoAlbumAdapter mVideoAlbumAdapter;
//    AdRequest adRequest;
//    AdView adView;
    private StaggeredGridLayoutManager gaggeredGridLayoutManager;
    private UnifiedNativeAd nativeAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myvideo);
        from = getIntent().getStringExtra("from");
        bindView();
        init();
//        loadAd();
        loadNativeAds();
        setupRecyclerFeed();
        addListener();

    }

    private void bindView() {
        ivBack = findViewById(R.id.ivBack);
        txtMainTitle = findViewById(R.id.tv_name);
        llcreatevideo = findViewById(R.id.ll_novideo);
        btncreatevideo = findViewById(R.id.iv_create_now);
        rvVideoList = findViewById(R.id.rvAlubmPhotos);
//        UtilsData.Textfont(this, txtMainTitle);

    }

    private void loadAd() {
//        adView = findViewById(R.id.adView);
//        adRequest = new AdRequest.Builder().build();
//        adView.loadAd(adRequest);
    }

    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.nativead));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Toast.makeText(activity, "Failed to load native ad: "
                        + errorCode, Toast.LENGTH_SHORT).show();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {
        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void addListener() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (from != null && from.equalsIgnoreCase("unity")) {
                    finish();
                } else {
                    onBackPressed();
                }
            }

        });
        btncreatevideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity, HomeActivity.class));
                finish();
            }
        });
    }

    private void init() {
        getVideoList();
        if (mVideoDatas.size() > 0) {
            llcreatevideo.setVisibility(View.GONE);
        } else {
            llcreatevideo.setVisibility(View.VISIBLE);
        }
    }


    private void getVideoList() {
        this.mVideoDatas = new ArrayList<VideoData>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getAPP_FOLDER() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoData videoData = new VideoData();
                videoData.videoDuration = cur.getLong(bucketColumn);
                videoData.videoFullPath = cur.getString(data);
                videoData.videoName = cur.getString(name);
                videoData.dateTaken = cur.getLong(dateTaken);
                if (new File(videoData.videoFullPath).exists()) {
                    this.mVideoDatas.add(videoData);
                }
            } while (cur.moveToNext());
        }
    }

    private void setupRecyclerFeed() {
        if (mVideoDatas.size() <= 0) {
            rvVideoList.setVisibility(View.GONE);
        } else {
            rvVideoList.setVisibility(View.VISIBLE);
        }
        mVideoAlbumAdapter = new VideoAlbumAdapter(activity, mVideoDatas);
        gaggeredGridLayoutManager = new StaggeredGridLayoutManager(2, 1);
        gaggeredGridLayoutManager.setAutoMeasureEnabled(true);
        rvVideoList.setLayoutManager(gaggeredGridLayoutManager);
        rvVideoList.setAdapter(mVideoAlbumAdapter);
        mVideoAlbumAdapter.notifyDataSetChanged();

    }

    public void onBackPressed() {
        Intent intent = new Intent(activity, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    public void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }
}
